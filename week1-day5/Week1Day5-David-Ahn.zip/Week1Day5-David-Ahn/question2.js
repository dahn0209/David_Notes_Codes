
function add(num1,num2,num3){
    return num1+num2+num3
}






const add2=num1=>num2=>num3=>num1+num2+num3