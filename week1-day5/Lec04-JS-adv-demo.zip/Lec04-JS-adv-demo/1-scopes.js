// if(true){
// 	//block scope
// }

// for(var m=0;m<10;m++){
// 	//block scope
// }

// {
// 	//block scope
// }

// function functionScope(){
// 	//function scope
// }

// --------------------------------------------------------------------------------------
// Global scope
// var globalV = 'globalV';
// function globalFunction() {
//   console.log("globalFunction()");
// }
// console.log("window =", window);
// console.log("window.globalV =", window.globalV);
// console.log("window.globalFunction =", window.globalFunction);