// console.log("window.globalV =", window.globalV);
// console.log("globalV =", globalV);
// console.log("window.globalFunction =", window.globalFunction);
// console.log("globalFunction =", globalFunction);
