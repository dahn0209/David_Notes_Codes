const Post = require("../models/Post");

exports.get_thread = (req, res) => { };
exports.post_newPost = (req, res) => { };
exports.post_comment = (req, res) => { };
exports.patch_update = (req, res) => { };