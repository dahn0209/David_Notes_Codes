function flightInterary(arr){

    let str=''
    
    for(let eachArr of arr){
        let eachObj=eachArr;

        for(let eachKey in eacbObj){
            
        }
    }
}