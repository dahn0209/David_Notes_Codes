// require('./utils');

// var does not create a global variable
// console.log("a =", a);

// -------------------------------------------
// Creating a global variable
// console.log("a =", a);
// console.log("a === global.a ?", a === global.a);

// --------------------------------------------------------------------------------------
// module-scoped objects

// const utils = require('./utils');
// console.log("require('./utils') =", utils);

// --------------------------------------------------------------------------------------
// built-in global objects

// console.log("process =", process);

// module.a = "script.js is main module";
// console.log("process.mainModule =", process.mainModule);

// console.log("process.env =", process.env);