const EventEmitter = require('events');
const eventEmitter = new EventEmitter();

eventEmitter.on("greeting", (msg, n) => {
  for (let i = 0; i < n; i++) {
    console.log(`${i + 1}: ${msg}`);
  }
});
module.exports = { eventEmitter };