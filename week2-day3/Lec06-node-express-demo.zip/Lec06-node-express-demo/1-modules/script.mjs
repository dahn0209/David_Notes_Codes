// ES Modules
// script.mjs
console.log("ESModules: script.mjs");
console.log(PI);
import { PI } from './utils.mjs';


