// -----------------------------------
// utils.js
console.log("CommonJS: utils.js");
module.exports = 3.14;