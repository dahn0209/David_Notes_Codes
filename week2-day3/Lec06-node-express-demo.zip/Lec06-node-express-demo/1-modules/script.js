// CommonJS
// script.js
console.log("CommonJS: script.js");
const PI = require('./utils');
console.log(PI);
